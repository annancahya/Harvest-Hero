package com.example.harvesthero

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class ProfileActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth

    private lateinit var tvUsername: TextView
    private lateinit var tvUserStatus: TextView
    private lateinit var profileImage: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        tvUsername = findViewById(R.id.username)
        tvUserStatus = findViewById(R.id.user_status)
        profileImage = findViewById(R.id.profile_image)

        // Load the data from SharedPreferences
        val sharedPreferences = getSharedPreferences("UserProfile", MODE_PRIVATE)
        val firstName = sharedPreferences.getString("FIRST_NAME", ".")
        val lastName = sharedPreferences.getString("LAST_NAME", ".")
        val description = sharedPreferences.getString("DESCRIPTION", "Description")
        val phone = sharedPreferences.getString("PHONE", "Default Phone")
        val email = sharedPreferences.getString("EMAIL", "Default Email")
        val profileImageUri = sharedPreferences.getString("PROFILE_IMAGE_URI", "")

        // Set the data to the TextViews
        tvUsername.text = "$firstName $lastName"
        tvUserStatus.text = description

        auth = FirebaseAuth.getInstance()

        findViewById<ImageView>(R.id.btnBeranda).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnSignOut).setOnClickListener {
            auth.signOut()
            startActivity(Intent(this, LoginActivity::class.java))
        }

        findViewById<Button>(R.id.btn_faq).setOnClickListener {
            auth.signOut()
            startActivity(Intent(this, PertanyaanActivity::class.java))
        }

        findViewById<Button>(R.id.btn_account).setOnClickListener {
            startActivity(Intent(this, ProfileEditActivity::class.java))
        }




    }

}