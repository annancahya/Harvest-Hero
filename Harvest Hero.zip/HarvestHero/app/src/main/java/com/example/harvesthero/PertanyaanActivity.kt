package com.example.harvesthero

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PertanyaanActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pertanyaan)
    }
}