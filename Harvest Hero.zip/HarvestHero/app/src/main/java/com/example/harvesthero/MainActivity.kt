package com.example.harvesthero

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<ImageView>(R.id.btnCameraX).setOnClickListener {
            val intent = Intent(this, CameraActivity::class.java)
            startActivity(intent)
        }

        findViewById<ImageView>(R.id.btnProfile).setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnTakePicture).setOnClickListener {
            startActivity(Intent(this,CameraActivity::class.java))
        }

    }
}

//        val takePictureButton: Button = findViewById(R.id.btnTakePicture)
//        takePictureButton.setOnClickListener {
//            moveToCameraActivity()
//        }


//    private fun moveToCameraActivity() {
//   val intent = Intent(this, CameraActivity::class.java)
//       startActivity(intent)
//       finish()
//    }

